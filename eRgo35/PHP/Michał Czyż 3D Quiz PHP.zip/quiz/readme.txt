Bazę Danych należy załadować do Bazy MySQL i następnie odpowiednio ustawić dostęp do bazy w pliku auth.php

Dla dobrego rezulatu najlepiej do folderu htdocs upuścić cały folder quiz i wtedy wejść na stronę za pomocą http://localhost/quiz