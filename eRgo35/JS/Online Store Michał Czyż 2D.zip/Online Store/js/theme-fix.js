var x = getCookie("theme");
if (x == "dark") {
    $("#clock").addClass("darkClock");
    $(".hand").addClass("darkHand");
}